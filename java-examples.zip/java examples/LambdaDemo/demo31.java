//method referencing in java
@FunctionalInterface
interface newInterface {
    public void myMethod();
}

// class MyClass {
// static void mymethod() {
// System.out.println("this is a static method");
// }
// }

public class demo31 implements newInterface {
    public static void main(String[] args) {
        demo31 d = new demo31();

        newInterface n = d::myMethod;
        n.myMethod();
    }

    @Override
    public void myMethod() {
        System.out.println("Lambda Expression");
    }
}