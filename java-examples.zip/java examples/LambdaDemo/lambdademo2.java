import java.util.*;

class lambdademo2 {
    public static void main(String[] args) {
        ArrayList<String> names = new ArrayList<String>();
        names.add("Abc");
        names.add("Bcd");
        names.add("Cde");

        names.forEach((n) -> System.out.println(n));
    }
}