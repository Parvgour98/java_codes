interface MyInterface {
    // public int sum(int a, int b);

    // public int sum(int a, int b, int c);

    public void function1(int x);
}

class lambdademo implements MyInterface {

    public static void main(String[] args) {
        MyInterface mi = (int x) -> System.out.println(x * 2);
        mi.function1(3);
        // MyInterface mi = (int a, int b) -> a + b;
        // System.out.println(mi.sum(3, 4));
        // // MyInterface mi1 = (int a, int b, int c) -> a + b + c;
        // System.out.println(mi1.sum(2, 3, 4));
    }
    // @Override
    // public int sum(int a, int b){
    // return a + b;
    // }
}