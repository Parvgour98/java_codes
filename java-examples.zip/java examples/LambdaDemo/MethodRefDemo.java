import java.util.*;
import java.util.stream.*;

class MethodRefDemo {
    public static void main(String[] args) {
        List<String> list = Arrays.asList("working", "with", "java", "and", "method", "references");

        List<String> sortedList = list.stream().sorted((s1, s2) -> s1.compareTo(s2))
                .collect(Collectors.toCollection(ArrayList::new));

        System.out.println(sortedList);

        List<String> sorted1 = list.stream().sorted(String::compareTo).collect(Collectors.toList());

        System.out.println(sorted1);
    }
}