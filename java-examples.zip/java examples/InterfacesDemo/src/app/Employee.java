package app;

public class Employee implements IEmployee {
    // member variables
    private int emp_id;
    private String emp_name;
    private String dept;
    static int i;

    Employee[] register = new Employee[5];

    // default constructor
    public Employee() {

    }

    // parameterized constructor
    public Employee(int e_id, String e_name, String dept) {
        this.emp_id = e_id;
        this.emp_name = e_name;
        this.dept = dept;
    }

    @Override
    public void addEmployee(Employee e) {
        register[i] = e;
        i++;
    }

    @Override
    public void ListEmployees() {
        for (Employee emp : register) {
            System.out.println("Employee ID: " + emp.emp_id + " Name: " + emp.emp_name + " Department: " + emp.dept);
            // if (emp.equals(null)) {
            // System.out.println("Nothing more to print");
            // System.exit(0);
            // } else {
            // System.out
            // .println("Employee ID: " + emp.emp_id + " Name: " + emp.emp_name + "
            // Department: " + emp.dept);
            // }

        }
    }

}