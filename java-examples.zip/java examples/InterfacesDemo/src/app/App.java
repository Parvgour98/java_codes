package app;

import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);

        System.out.println("Employee Id: ");
        int e_id = sc.nextInt();
        System.out.println("Employee Name: ");
        String e_name = sc.next();
        System.out.println("Department: ");
        String dept = sc.next();

        // calls the default constructor
        Employee e = new Employee(e_id, e_name, dept);
        e.addEmployee(e);
        e.ListEmployees();

    }
}