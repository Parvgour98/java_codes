package app;

interface IEmployee {
    public void addEmployee(Employee e);

    public void ListEmployees();
}