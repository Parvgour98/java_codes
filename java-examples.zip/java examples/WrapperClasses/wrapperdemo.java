enum Gender {
    M, F
}

enum persons {
    alexa(10), prathima(21), dawar(20), tharun(22);

    private int age;

    private persons(int age) {
        this.age = age;
    }

    int getAge() {
        return age;
    }
}

class wrapperdemo {
    String name;
    int id;
    Gender gender;

    wrapperdemo(String name, int id, Gender gender) {
        this.name = name;
        this.id = id;
        this.gender = gender;
    }

    wrapperdemo() {

    }

    public static void main(String[] args) {
        // wrapperdemo wp = new wrapperdemo();
        // wp.name = " qwe";
        // wp.id = 1;
        // wp.gender = Gender.E;
        // System.out.println(wp.name);
        // System.out.println(wp.id);
        // System.out.println(wp.gender);

        // persons p;

        System.out.println(persons.alexa.getAge());
    }
}
