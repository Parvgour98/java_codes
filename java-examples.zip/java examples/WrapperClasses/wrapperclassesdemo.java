class wrapperclassesdemo {
    public static void main(String[] args) {
        // primitive data types
        byte b = 10;
        short s = 20;
        long l = 30;
        int i = 40;
        char c = 'a';
        boolean b1 = true;

        // autoboxing: converts a primitive datatype into an object
        Byte byte1 = b;
        Short s1 = s;
        Long l1 = l;
        Integer i1 = i;
        Character ch = c;
        Boolean b2 = b1;

        System.out.println("Byte datatype: " + b);
        System.out.println("-------Wrapper Objects--------");
        System.out.println(byte1);
        System.out.println(s1);
        System.out.println(l1);

        byte1 = 20;
        i1 = 50;

        // unboxing
        b = byte1;
        System.out.println("After unboxing - byte: " + b);

    }
}