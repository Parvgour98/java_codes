package demos;

import java.util.Scanner;

public class SwitchCaseTest{

      public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
         System.out.println("Enter name: ");
         String name = sc.next();
         System.out.println("Age please");
         int age = sc.nextInt();
         System.out.println("Location? (c/v");
         char loc = sc.next().charAt(0);
         System.out.println("Gender? (m/f)");
         char gender = sc.next().charAt(0);

         switch(gender){
               case 'm':
               case 'M': if(age >=15 && age < 30){

               }
               break;
         }

//          System.out.println("Enter day number: ");
//          int day_no = sc.nextInt();

//          switch(day_no){
//              case 1: System.out.println("Monday");
//                      break;
//              case 2: System.out.println("Tuesday");
//                      break;
//              default: System.out.println("Invalid day");
//                       break;
//          }

      }
}