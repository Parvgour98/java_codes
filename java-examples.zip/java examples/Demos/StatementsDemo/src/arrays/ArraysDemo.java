package arrays;

import java.util.Scanner;

public class ArraysDemo{
           Scanner sc = new Scanner(System.in);
           
           //syntax 
           /*
                    access_specifier return_type method_name(parameters){}
           */ 
          int[][] accept_Details(){
              int[][] a = new int[2][2] ; 
              for(int i=0;i<2;i++){
                for(int j=0;j<2;j++){
                    a[i][j]=sc.nextInt();
                }
              }
              return a;
          }

          int[][] AddMatrix(int[][] a, int[][] b){
                int[][] res = new int[2][2];
                for(int i = 0;i<2;i++){
                    for(int j = 0;j<2;j++){
                        res[i][j] = a[i][j] + b[i][j];
                    }
                }
                return res;
          }

          int[][] MultiplyMatrix(int[][] a, int[][] b){
            int[][] res = new int[2][2];
            for(int i = 0;i<2;i++){
                for(int j = 0;j<2;j++){
                    res[i][j] = (a[i][j] * b[i][j]);
                }
            }
            return res;
          }

          
           public static void main(String[] args) {
                 ArraysDemo ad = new ArraysDemo();
                 int choice;
                 int[][] n = new int[2][2];
                 int[][] m = new int[2][2];
                 int[][] res = new int[2][2];
                                  
                 do{
                      System.out.println("1. Accept Matrix Details");
                      System.out.println("2. Add matricies");
                      System.out.println("3. Multiply Matricies");
                      System.out.println("4. Exit");

                      System.out.println("Enter choice: ");
                      choice = ad.sc.nextInt();

                      switch(choice){
                          case 1: System.out.println("Accepting array 1");
                                  n=ad.accept_Details();
                                  System.out.println("Accepting array 2");
                                  m = ad.accept_Details();
                             break;
                          case 2: res = ad.AddMatrix(n, m);
                                for(int i = 0; i<2;i++){
                                    for(int j =0;j<2;j++){
                                        System.out.print(res[i][j] + " ");
                                    }
                                    System.out.println(" ");
                                }
                                break;
                          case 3: res = ad.MultiplyMatrix(n, m);
                                for(int i = 0; i<2;i++){
                                    for(int j =0;j<2;j++){
                                        System.out.print(res[i][j] + " ");
                                    }
                                    System.out.println(" ");
                                }
                                 break;
                          default: System.out.println("Invalid choice");
                            System.exit(0);
                      }
                 }while(choice > 0 && choice < 4);
           }
}