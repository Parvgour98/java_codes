package app;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int age = sc.nextInt();
        String name = sc.next();
        char loc = sc.next().charAt(0);
        char gender = sc.next().charAt(0);
        
        switchcaseDemo(age, name, loc, gender);


        sc.close();
    }

    static void switchcaseDemo(int age, String name, char loc, char gender){
        // switch(age){
        //     case 
        // }
        System.out.println("In switch case method");
    }
}