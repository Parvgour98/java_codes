package app;

public class App {
    public static void main(String[] args) throws Exception {
        int n = 0; // variable declaration and initialization

        // while
        // while (n < 5) {
        // System.out.println("tick: " + n);
        // n++;
        // }
        // System.out.println("Value of n: " + n);

        // do .. while
        // do {
        // System.out.println("Tick: " + n);
        // ++n;
        // } while (n < 5);
        // System.out.println("Value of n: " + n);

        for (int i = 0; i < 5; i++) {
            System.out.println(i);
        }

        // System.out.println("outside for:" + i);

    }
}