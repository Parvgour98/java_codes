package menuProgram;

import java.util.Scanner;

public class MenuDemo {
    // class scope
    Scanner sc = new Scanner(System.in);

    // member methods
    // add
    void add() {
        System.out.println("enter n1");
        int n1 = sc.nextInt();
        System.out.println("enter n2");
        int n2 = sc.nextInt();

        System.out.println(n1 + " + " + n2 + " = " + (n1 + n2));
    }

    public static void main(String[] args) {
        int choice = 1;
        // Scanner sc1 = new Scanner(System.in); //local to main
        MenuDemo md = new MenuDemo();

        while (choice > 0 && choice < 5) {
            System.out.println("1. Add");
            System.out.println("2. Subtract");
            System.out.println("3. Multiply");
            System.out.println("4. Divide");
            System.out.println("5. Exit");

            System.out.println("Enter your choice (1 - 4): ");
            choice = md.sc.nextInt();
            switch (choice) {
            case 1:
                md.add();
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            default:
                System.out.println("Exiting!!!");
                System.exit(0);
            }
        }
    }
}