import java.util.Scanner;

public class exceptionsdemo {
    static int divide(int a, int b) {
        if (b == 0) {
            throw new ArithmeticException();
        }
        return (a / b);
    }

    public static void main(String[] args) {
        int result;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter numerator: ");
        int numerator = sc.nextInt();
        System.out.println("Enter denominator:");
        int denominator = sc.nextInt();

        try {
            result = divide(numerator, denominator);
            System.out.println(result);
        } catch (ArithmeticException e) {
            System.out.println("Cannot divide by zero " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Generic Exception " + e.getMessage());
        } finally {
            System.out.println("In finally");
        }

        sc.close();

    }
}
