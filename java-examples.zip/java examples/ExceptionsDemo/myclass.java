public class myclass {
    static void checkAge(int age) throws ArithmeticException {
        if (age < 18) {
            throw new ArithmeticException("access denied");
        } else {
            System.out.println("Acess granted");
        }
    }

    public static void main(String[] args) {
        try {
            checkAge(11);
        } catch (ArithmeticException e) {
            System.out.println("exception handled");

        }
    }
}
