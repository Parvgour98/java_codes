class examp1 {
    public static void main(String[] args) {

        StringBuilder sb = new StringBuilder("hello");
        // sb.append("java");
        // sb.insert(1, "java");
        // sb.replace(1, 4, "java");
        // sb.delete(4, 5);
        // sb.reverse();
        System.out.println(sb.capacity());
        // // sb.append("hello");
        // System.out.println(sb.capacity());
        // sb.append("i hate java programming");
        // System.out.println(sb.capacity());

    }
}