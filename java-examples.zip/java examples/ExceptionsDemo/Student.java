public class Student {
    int S_id;
    String s_name;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + S_id;
        result = prime * result + ((s_name == null) ? 0 : s_name.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Student other = (Student) obj;
        if (S_id != other.S_id)
            return false;
        if (s_name == null) {
            if (other.s_name != null)
                return false;
        } else if (!s_name.equals(other.s_name))
            return false;
        return true;
    }

    public static void main(String[] args) {
        Student sc = new Student();
        Student s = new Student();
        sc.S_id = 123;
        sc.s_name = "abc";
        System.out.println(sc.hashCode());
        System.out.println(sc.equals(s));
    }

}