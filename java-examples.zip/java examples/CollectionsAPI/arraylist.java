import java.awt.List;
import java.util.ArrayList;

class Student {
    // private int s_id;
    private String name;

    // public void setId(int id) {
    // this.s_id = id;
    // }

    public void setName(String name) {
        this.name = name;
    }

    // public int getId() {
    // return s_id;
    // }

    public String getName() {
        return name;
    }

}

public class arraylist {

    public static void main(String[] args) {
        ArrayList<String> names = new ArrayList();

        ArrayList<Student> st = new ArrayList();

        Student s = new Student();
        // s.setId(1);
        s.setName("name");

        // System.out.println(s.getId());
        System.out.println(s.getName());

        st.add(1, s);

        names.add("Prithvi");
        names.add("Harshita");
        names.add("Dharshan");

        for (String s1 : names) {
            System.out.println(s1);
        }

        System.out.println(names.isEmpty());

    }

}