class Student {
    private int s_id;
    private String name;

    public int getS_id() {
        return s_id;
    }

    public void setS_id(int s_id) {
        this.s_id = s_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}

public class demo2 {
    public static void main(String[] args) {
        Student s = new Student();
        s.setS_id(1);
        s.setName("name");

        System.out.println(s.getS_id());
        System.out.println(s.getName());

    }
}