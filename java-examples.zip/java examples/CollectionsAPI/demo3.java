//using the iterator to run through an array

import java.util.*;

class person {
    private int personid;
    private String name;

    // getters
    public int getPersonId() {
        return personid;
    }

    public String getName() {
        return name;
    }

    // setters
    public void setPersonId(int id) {
        this.personid = id;
    }

    public void setName(String name) {
        this.name = name;
    }

}

class demo3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int ch;

        // ArrayList<String> list = new ArrayList<String>();
        ArrayList<person> persons = new ArrayList<person>();

        while (true) {
            System.out.println("=======Menu========");
            System.out.println("1. Add a person");
            System.out.println("2. Remove a person");
            System.out.println("3. List all persons");
            System.out.println("4. Exit");

            System.out.println("Your choice please");
            ch = sc.nextInt();

            switch (ch) {
                case 1:
                    System.out.println("Enter id:");
                    int id = sc.nextInt();
                    System.out.println("Enter name: ");
                    String n = sc.next();
                    person p = new person();
                    p.setPersonId(id);
                    p.setName(n);
                    persons.add(p);
                    break;
                case 2:
                    System.out.println("Enter name of person to remove: ");
                    n = sc.next();
                    for (Iterator<person> itr = persons.iterator(); itr.hasNext();) {
                        if (itr.next().getName().equals(n)) {
                            System.out.println("Object found and removed");
                            itr.remove();
                        } else {
                            System.out.println("Object not found");
                        }
                    }
                    break;
                case 3:
                    Iterator<person> it = persons.iterator();
                    System.out.println("Printing List ---- ");
                    while (it.hasNext()) {
                        System.out.println("id: " + it.next().getPersonId() + " Name: " + it.next().getName());
                    }
                    break;
                default:
                    System.out.println("Invalid Option!!! Exiting!!!");
                    sc.close();
                    System.exit(0);
                    break;
            }
        }

        // Adding object in arraylist
        // list.add("Prithvi");
        // list.add("Prasad");
        // list.add("Komal");
        // list.add("Kumud");
        // list.add("Prithvi");

        // // remove an element
        // System.out.println("Initial List: " + list);
        // list.remove(2);

        // System.out.println("After remove(2): " + list);
        // // removes first occurence/only occurence
        // boolean removed = list.remove("Prithvi");
        // System.out.println("After: " + list);

        // // removeall
        // list.removeAll(list);

        // // persons.add(p);

        // // Traversing list through Iterator
        // Iterator itr = list.iterator();
        // while (itr.hasNext()) {
        // System.out.println(itr.next());
        // }

        // // System.out.println(list.get(1));

    }
}