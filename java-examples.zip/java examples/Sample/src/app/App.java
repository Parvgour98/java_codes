package app;

public class App {
    public static void main(String[] args) 
    {
        Student s1 = new Student();
        Student s2 = new Student();

        s1.course_id = 100;
        s1.addStudent(001, "Prithvi");
        s2.addStudent(002, "Pallavi");
        s1.display();
        s2.display();
        Student.method1();
    //    int x = 12;
    //    int y = 23;

    //    System.out.println("Addition: " + (x+y));



    }
}