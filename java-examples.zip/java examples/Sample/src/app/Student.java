package app;

class Student{
      private int s_id;
      private String s_name;
      static int course_id;

      void addStudent(int s_id, String s_name){
            this.s_id = s_id;
            this.s_name = s_name;
      }
      void display(){
            System.out.println("Id: "+ s_id + " Name: " + s_name);
            System.out.println("Course Id: " + course_id);
      }

      static void method1(){
             System.out.println("In static method");
      }
}