package demos;

import java.util.Scanner;

class numbers {
    static void greatestNumber(int a, int b, int c) {
        if (a > b) {
            if (a > c) {
                System.out.println(a);
            }
        } else {
            if (b > c) {
                System.out.println(b);
            } else {
                System.out.println(c);
            }
        }
    }
}

public class statementsDemo {

    static boolean isPrime(int num) {
        if (num <= 1)
            return false;

        // Check from 2 to num-1
        for (int i = 2; i < num; i++) {
            if (num % i == 0)
                return false;
        }

        return true;
    }

    static void divide(int a, int b) {
        // if construct
        if (b > 0) {
            System.out.println("On division: " + (a / b));
        } else {
            System.out.println("Denominator cannot be 0!!!!");
        }

    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        // int num = in.nextInt();
        // boolean prime = isPrime(num);
        // if (prime == true) {
        // System.out.println(num + " is prime");
        // } else
        // System.out.println(num + " is not a prime");
        // System.out.println("Enter numerator:");
        // int a = in.nextInt();
        // System.out.println("Enter denominator:");
        // int b = in.nextInt();
        // divide(a, b);

        int x = in.nextInt();
        int y = in.nextInt();
        int z = in.nextInt();

        numbers.greatestNumber(x, y, z);
        // System.out.println(a);
        in.close();
    }
}