package app;

public class FloatandDoubleTest {
    public static void main(String[] args) {
        float myfloat1 = (float) 128.463779277766666555652100;// it can only hold limited precision.
        System.out.println(myfloat1);

        float myfloat2 = (float) -128.56719;// wrong number is printed.
        System.out.println(myfloat2);

        float myfloat3 = (float) 128.5677;// ok
        System.out.println(myfloat3);

        double mydouble1 = 128.4637792777666695556521001;// limited and strange precision.
        System.out.println(mydouble1);

        double mydouble2 = 128.4637792777666185556521001;// strange precision.
        System.out.println(mydouble2);

        double mydouble3 = 128.4637792777;// ok.
        System.out.println(mydouble3);

        double mydouble4 = 1.2345E2;
        System.out.println(mydouble4);
    }
}