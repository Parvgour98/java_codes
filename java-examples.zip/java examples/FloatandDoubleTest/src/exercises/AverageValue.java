package exercises;

import java.util.Scanner;

class ArithmeticOps {
    int average(int a, int b, int c) {
        return (a + b + c) / 3;
    }

}

public class AverageValue {
    public static void main(String[] args) {
        // read information from keyboard using System.in
        // Scanner class will facilitate this process
        Scanner scan = new Scanner(System.in);

        // accepting 3 numbers
        System.out.println("enter first number");
        int num1 = scan.nextInt();
        System.out.println("enter second number");
        int num2 = scan.nextInt();
        System.out.println("enter third number");
        int num3 = scan.nextInt();

        ArithmeticOps ar = new ArithmeticOps();

        System.out.println("Average of " + num1 + " , " + num2 + " , " + num3 + " = " + ar.average(num1, num2, num3));

        scan.close();

    }
}