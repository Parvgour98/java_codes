
public class StringsDemo {
    public static void main(String[] args) {
        // String s = "Hello";
        // System.out.println(s);
        // s = s.concat("Java");
        // System.out.println(s);

        StringBuilder sb = new StringBuilder("Hello");
        // sb.append("Hello");
        System.out.println(sb);
        sb.append(" Java");
        System.out.println(sb);
    }
}