package AnonymousClassesDemo.examples;

public class tostringex {
    // int rollno;
    // String name;

    // tostringex(int rollno, String name) {
    // this.rollno = rollno;
    // this.name = name;
    // }

    // @Override
    // public String toString() {
    // // TODO Auto-generated method stub
    // return rollno + " " + name;
    // }

    public static void main(String[] args) {
        //

    }
}