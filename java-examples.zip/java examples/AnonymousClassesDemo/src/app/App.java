package app;

interface Age {
    // public int x = 21;

    public void getAge();
}

// class NewAge implements Age {
// @Override
// public void getAge() {
// System.out.println("getting age " + x);
// }
// }

public class App {
    public static void main(String[] args) throws Exception {
        int x = 21;
        // Age obj1 = new Age(){
        // @Override
        // public void getAge() {
        // System.out.println("getting age " + x);
        // }
        // };
        // obj1.getAge();
        // n.getAge();

        // method with no parameters
        Age obj = () -> {
            System.out.println("getting Age: " + x);
        };
        obj.getAge();
    }
}