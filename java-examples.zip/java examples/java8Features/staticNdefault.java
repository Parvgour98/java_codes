interface Iinterface {
    // static int i=0;
    static void hello() {
        System.out.println("Hello");
    }

    default void newMethod() {
        System.out.println("Default in Interface");
    }
}

class staticNdefault implements Iinterface {

    public static void main(String[] args) {
        Iinterface.hello();
        hello();
        // Iinterface itr = new staticNdefault();
        // itr.newMethod();
        staticNdefault s = new staticNdefault();
        s.newMethod();
    }

    // @Override
    // public void newMethod() {
    // // TODO Auto-generated method stub
    // Iinterface.super.newMethod();
    // }

    static void hello() {
        System.out.println("In class");
    }

}