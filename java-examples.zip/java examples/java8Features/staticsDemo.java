class StaticClass {
    static int i;

    static void Mymethod() {
        System.out.println("In base class");
    }
}

class staticsdemo extends StaticClass {
    public static void main(String[] args) {
        Mymethod();
    }
}