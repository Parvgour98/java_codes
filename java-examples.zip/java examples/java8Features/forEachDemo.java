import java.util.ArrayList;
import java.util.List;

class forEachDemo {
    public static void main(String[] args) {
        List<String> lst = new ArrayList<>();

        // adding items to list
        lst.add("A");
        lst.add("B");
        lst.add("C");
        lst.add("D");

        // //extended for loop
        // for(String s : lst){
        // System.out.println(s);
        // }

        // forEach
        lst.forEach(System.out::println);
        System.out.println("--------------------");
        // forEach with if
        lst.forEach(s -> {
            if (s.equals("C")) {
                System.out.println(s);
            }
        });
    }
}