package com.training.ui;

import java.util.ArrayList;
import java.util.List;

import com.training.bean.Book;

public class Main4 {

	public static void main(String[] args) {
		Book book1 = new Book("Java Complete Reference", "Java", 600.00,
				"Herbert Childt");
		Book book2 = new Book("Java in a Box", "Java", 750.00,
				"Bruce Eckel");
		Book book3 = new Book("Java examples in a nutshell", "Java", 400.00,
				"David Flanagan");
		
		Book book4 = new Book("HTML and CSS", "Web", 490.00,
				"Jon Duckett");
		Book book5 = new Book("Introducing HTML5", "Web", 340.00,
				"Bruce Lawson");
		
		Book book6 = new Book("Programming in ANSI C ", "C", 350.00,
				" Balagurusamy ");
		Book book7 = new Book("Let Us C", "C", 200.00,
				"Yashavant Kanetkar");
		Book book8 = new Book("Head First C", "C", 450.00,
				"Griffiths David");

		List<Book> bookList = new ArrayList<Book>();
		bookList.add(book1);
		bookList.add(book2);
		bookList.add(book3);
		
		bookList.add(book4);
		bookList.add(book5);
		bookList.add(book6);
		
		bookList.add(book7);
		bookList.add(book8);
		
		System.out.println(bookList);
		
	}
}
