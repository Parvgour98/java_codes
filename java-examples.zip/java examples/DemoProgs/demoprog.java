enum Gender {
    MALE, FEMALE
};

class Customer {
    int id;
    String name;
    Gender g;
    int discount;

    Customer() {

    }

    Customer(int id, String name, Gender g, int discount) {

    }

    int getId() {
        return id;
    }

    String getName() {
        return name;
    }

    Gender getGender() {
        return g;
    }

}

class Account {

}

public class demoprog {

}