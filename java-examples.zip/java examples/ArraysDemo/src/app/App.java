package app;

import java.util.Arrays;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        int[] student_id = new int[5];
        for (int i = 0; i < 5; i++) {
            student_id[i] = sc.nextInt();
        }

        Arrays.sort(student_id);
        // for each loop demo
        for (int id : student_id) {
            System.out.println(id);
        }

        sc.close();
    }
}