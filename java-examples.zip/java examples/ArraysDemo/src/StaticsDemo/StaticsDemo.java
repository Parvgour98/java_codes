package StaticsDemo;

public class StaticsDemo {
    // non-static variables
    int a;
    // static variables
    static int var;
    // static block
    static {
        var = 9;
        System.out.println("In static block");
    }

    // static method
    static void method1() {
        System.out.println("In static method");
    }

    // static classes
    static class Inner {
        void myMethod() {
            System.out.println("Inside the static class");
        }

        static void newMethod() {
            System.out.println("Inside the static class - static method");
        }
    }

    public static void main(String[] args) {
        System.out.println("In main");
        method1();

        StaticsDemo.Inner inner = new StaticsDemo.Inner();
        inner.myMethod();
        StaticsDemo.Inner.newMethod();

    }
}