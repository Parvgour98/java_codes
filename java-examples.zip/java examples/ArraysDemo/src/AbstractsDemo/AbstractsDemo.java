package AbstractsDemo;

abstract class Vehicle {
    //member variables or class variables or attributes 
    // or properties
    int no_gears;
    String brand;
    String driving_mode;
    int no_wheels;

    // concrete method
    void hasWheels() {
        System.out.println("has wheels");
    }

    // abstract method declaration
    abstract void start();
}

class Bike extends Vehicle {

    @Override
    void start() {
        System.out.println("Starting bike");
    }
}

public class AbstractsDemo {

    public static void main(String[] args) {
        Bike b = new Bike();
        b.start();
    }
}