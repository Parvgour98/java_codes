package StringsDemo;

public class StringsDemo {

    public static void main(String[] args) {
        String str = "Hello Java";
        String str1 = "Hi";
        char[] ch = { 'p', 'l', 'a', 'c', 'e' };
        String s = new String(ch);

        // splitting a string
        String[] str2 = str.split(" ");
        for (int i = 0; i < str2.length; i++) {
            System.out.println(str2[i]);
        }

        // concatenating a string
        String str3 = str.concat(str1);
        System.out.println(str3);
        // length
        // equals
        boolean answer = str.equals(str1);
        System.out.println(answer);
        // equalsIgnoreCase
        // reverse
        String strrev = "";
        for (int i = str.length() - 1; i >= 0; i--) {
            strrev = strrev + str.charAt(i);
        }
        System.out.println(strrev);
        // substring

        String sub = str.substring(2);
        System.out.println(sub);
        // replace

        // join
        String r = String.join(" , ", str, str1);
        System.out.println(r);

        // toUpperCase
        // toLowerCase
        // trim
        // contains
        // indexOf

        // System.out.println(str.compareTo(str1));
        // System.out.println(str);

        // str = str + " Java";
        // System.out.println(str);
    }
}