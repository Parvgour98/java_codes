package datatype;

public class abc {
    public static void main(String[] args) {
        char C = 'M';
        int a = 65535;
        byte b1 = -128;
        byte b2 = 127;
        int i1 = -2147483648;
        int i2 = 2147483647;
        short s1 = -32768;
        short s2 = 32767;
        long l1 = 9223372036854775807L;
        long l2 = -9223372036854775807L;
        System.out.println("Char is " + C);
        System.out.println("high range of int" + a);
        System.out.println("low range of byte" + b1);
        System.out.println("high range of byte" + b2);
        System.out.println("high range of long" + l1);
        System.out.println("low range of long" + l2);
        System.out.println("low range of integer" + i1);
        System.out.println("high range of byte" + i2);
        System.out.println("low range of short" + s1);
        System.out.println("high range  of short" + s2);

    }
}
