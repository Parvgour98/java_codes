package datatype;

public class loops {
    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            System.out.println(i);
        }
        int s = 1;
        while (s < 3) {
            System.out.println(s);
            s++;
        }
        int k = 0;
        do {
            System.out.println(k);
            k++;
        } while (k < 4);

    }
}