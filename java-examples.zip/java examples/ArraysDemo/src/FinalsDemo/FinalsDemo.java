package FinalsDemo;

final class SuperClass {
    final void method1() {
        System.out.println("In Super");
    }
}

// class SubClass extends SuperClass {

// // @Override
// // void method1() {
// // System.out.println("In sub");
// // }
// }

public class FinalsDemo {

    final int x = 10;

    public static void main(String[] args) {
        // x = 20;

        SuperClass sp = new SuperClass();
        sp.method1();
        // SubClass sb = new SubClass();
        // sb.method1();
    }
}