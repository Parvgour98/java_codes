package app;

/* this class will depict the different
calculator operations like add, multiply, divide
and subtract
*/
class Calculator {
    // variables
    int num1;
    int num2;
    int result = 0;

    // methods
    int add() {
        return num1 + num2;
    }

}

public class App {
    public static void main(String[] args) throws Exception {
        int s_id = 1;
        String s_name = "Prithvi";

        StudentDetails sd = new StudentDetails();
        sd.acceptDetails(s_id, s_name);
        sd.printDetails();


        // Calculator calc = new Calculator();
        // calc.num1 = 12;
        // calc.num2 = 23;
        // calc.result = calc.add();
        // System.out.println(calc.result);

        // System.out.println("Hello Java");
    }
}