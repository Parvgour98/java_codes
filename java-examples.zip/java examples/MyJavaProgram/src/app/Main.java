package app;

class StudentDetails {
    // private variables
    // indirect access for the object of this class
    private int student_id;
    private String s_name;

    // access methods
    void acceptDetails(int s_id, String s_name) {
        this.student_id = s_id;
        this.s_name = s_name;
    }

    void printDetails() {
        System.out.println("ID: " + student_id + " Name: " + s_name);
    }
}