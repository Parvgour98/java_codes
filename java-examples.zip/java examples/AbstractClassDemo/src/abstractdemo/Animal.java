package abstractdemo;

public abstract class Animal {
    public abstract void speak();

    public abstract void run();

    public abstract void eat();
}