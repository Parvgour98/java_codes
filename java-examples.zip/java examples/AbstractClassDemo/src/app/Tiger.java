package app;

import abstractdemo.*;

class Tiger extends Animal {

    @Override
    public void speak() {
        // TODO Auto-generated method stub

    }

    @Override
    public void run() {
        // TODO Auto-generated method stub

    }

    @Override
    public void eat() {
        // TODO Auto-generated method stub

    }

}