package app;

public class App {
    static boolean compare(EqualsDemo e1, EqualsDemo e2) {
        if (e1.equals(e2)) {
            return true;
        }
        return false;
    }

    public static void main(String[] args) throws Exception {
        // Test t = new Test();
        // t.sum(3, 4);
        // t.sum(1, 2, 3);

        // boolean b;
        EqualsDemo e1 = new EqualsDemo();
        EqualsDemo e2 = new EqualsDemo();

        e1.setId(2);
        e2.setId(2);

        // shallow compare
        System.out.println(compare(e1, e2));
        System.out.println("e1 hashcode:" + e1.hashCode());
        System.out.println("e2 hashcode:" + e2.hashCode());
    }
}