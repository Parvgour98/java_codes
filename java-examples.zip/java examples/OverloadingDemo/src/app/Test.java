package app;

class Test {
    public void sum(int a, int b) {
        System.out.println(a + " + " + b + " = " + (a + b));
    }

    // overloaded method
    public void sum(int a, int b, int c) {
        System.out.println(a + " + " + b + " + " + c + " = " + (a + b + c));
    }

    @Override
    public String toString() {
        // return super.toString();

        return "Overridden toString()";
    }
}