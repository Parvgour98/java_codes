package app;

class EqualsDemo {
    private int id;

    void setId(int id) {
        this.id = id;
    }

    int getId() {
        return id;
    }
}