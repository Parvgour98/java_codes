package com.daoclasses;

import org.skife.jdbi.v2.DBI;

class DBconnection {
    public final DBI getConnect() {
        try {
            // Handle h = null;
            // Class.forName("com.mysql.cj.jdbc.Driver");
            DBI dbi = new DBI("jdbc:mysql://localhost:3306/carsDemo?useSSL=false", "root", "Password123");

            System.out.println("Connected.......");
            return dbi;

        } finally {
            System.out.println("done");
        }
    }
}