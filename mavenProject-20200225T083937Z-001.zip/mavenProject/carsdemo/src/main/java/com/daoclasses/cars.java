package com.daoclasses;

class cars {
    private String carName;
    private double price;

    public cars() {

    }

    public cars(String name, double price) {
        this.carName = name;
        this.price = price;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return carName + " " + price;
    }

}